import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import AuthNavigator from './navigation/AuthNavigator'; // Kirjautumisreitit
import MainNavigator from './navigation/MainNavigator'; // Pääsovellusreitit
import AsyncStorage from '@react-native-async-storage/async-storage';

const App = () => {
    const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

    useEffect(() => {
        const checkAuthStatus = async () => {
            const token = await AsyncStorage.getItem("token");
            setIsAuthenticated(!!token); // Jos token on olemassa, käyttäjä on kirjautunut
        };

        checkAuthStatus();
    }, []);

    if (isAuthenticated === null) {
        return null; // Näytetään tyhjä näkymä ennen kuin tiedetään käyttäjän tila
    }

    return (
        <NavigationContainer>
            {isAuthenticated ? <MainNavigator /> : <AuthNavigator />}
        </NavigationContainer>
    );
};

export default App;
